//собираем все инпуты в одну переменную (делаем список инпутов)
let inputs = document.getElementsByTagName('input');
//вызываем функцию
addEventListnersToInputs(inputs);


function onKeyUp(e) {
	//проверяем, что на всех инпутах появились ивенты
	//console.log("кнопка отпущена");
	//проверяем появление ивента на конкретном инпуте (учитывается по id инпута)
	//console.log(e.target.id);

	// switch - аналог if. в зависимости от id инпута, будет выполняться код
	switch (e.target.id) {
		case 'username' :
		{
			usernameValidate(e.target);
			break ;
		}
		case 'phone' :
		{
			phonenumberValidate(e.target);
			break ;
		}
	}
}

// вводим функцию для проверки поля юзернэйм
function usernameValidate(input) {
	let validInput = '';
	//переменная для обозначения условий для поля ФИО 
	let regexp = /[А-Яа-яЁё\s\-]/g;
	//переменная, которая содержит проверку
	let validSymbolsArray = input.value.match(regexp);
	if(validSymbolsArray) {
		//проверяем все символы
		validSymbolsArray.forEach(function(symbol) {
		//создаем массив из подходящих символов
			validInput += symbol;
		});
	} else {
		alert("Допускаются только русские буквы, пробелы, тире")  }
	//выводим подходящие символы
	input.value = validInput;	
}

// вводим функцию для проверки поля номер телефона
function phonenumberValidate(input) {
	let validInput = '';
	//переменная для обозначения условий для поля  
	let regexp = /[0-9\-\+]/g;
	//переменная, которая содержит проверку
	let validSymbolsArray = input.value.match(regexp);
	if(validSymbolsArray) {
		//проверяем все символы
		validSymbolsArray.forEach(function(symbol) {
		//создаем массив из подходящих символов
			validInput += symbol;
		});
	} else {
		alert("Номер телефона должен содержать только цифры, -, +, пробелы")  }
	//выводим подходящие символы
	input.value = validInput;	
}

// вводим функцию для добавления ивента на инпут
function addEventListnersToInputs(inputs) {
	//превращаем список инпутов в массив
	let inputsArray = Array.from(inputs);
	//перебираем все инпуты 
	inputsArray.forEach(function(input) {
		//для каждого элемента в массиве добавляем ивент - 
		//keyup - когда юзер заканчивает заполнять поле(отпускает клавиши), включается проверка
		input.addEventListener('keyup', {
			handleEvent: onKeyUp

		})
	});
}


